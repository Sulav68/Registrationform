# raprapa_odoo

## This is a odoo module for obtaining membership in a political party.
### Put this module in your addons folder and refresh the server and it should work.
